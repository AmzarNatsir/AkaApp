(function () {
  ("use strict");
  // 1. Basic Select

  // The DOM element you wish to replace with Tagify
  var input = document.querySelector("input[name=basic-tags]");

  // initialize Tagify on the above input node reference
  new Tagify(input);

  // The DOM element you wish to replace with Tagify
  var input = document.querySelector("input[name=basic-tags1]");

  // initialize Tagify on the above input node reference
  new Tagify(input);
})();
